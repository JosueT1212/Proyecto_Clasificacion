#------------------------------------------------------------------------------------------------------------------
#   Mobile sensor data acquisition and processing
#------------------------------------------------------------------------------------------------------------------
import pickle
import numpy as np
from scipy import stats

# Load data
file_name = '06_05_2025_12_06_57.obj'
inputFile = open(file_name, 'rb')
experiment_data = pickle.load(inputFile)

# Process each trial and build data matrices
features = []
for tr in experiment_data:
    
    # For each signal (one signal per axis)
    feat = [tr[1]]
   
    for s in range(tr[2].shape[1]):
        sig = tr[2][:,s]
        n=len(sig)
        feat.append(np.average(sig)) # Promedio
        feat.append(np.std(sig)) #Desviavón Standard
        feat.append(stats.kurtosis(sig)) #Kurtosis
        feat.append(stats.skew(sig)) #Skewness
        feat.append(stats.median_abs_deviation(sig)) # MAD
        ZCR=0
        for i in range(0,n-1): 
            if sig[i]*sig[i+1] < 0:
                ZCR+=1
        ZCR/=n-1
        feat.append(ZCR) # Zero Crossing Rate
        rms = np.sqrt( np.sum(sig**2)/n) 
        feat.append(rms)#Root Mean Square
        SSC=0
        for i in range(1,n-1): 
            if (sig[i]-sig[i-1])*(sig[i]-sig[i+1]) > 0:
                SSC+=1
        feat.append(SSC)      #Slope sign changes  
        WL= np.sum(np.abs(np.diff(sig)))
        feat.append(WL)  #Waveform Length
        Energy=np.sum(sig**2)
        feat.append(Energy) #Energy
    
    features.append(feat)      

# Build x and y arrays
processed_data =  np.array(features)
x = processed_data[:,1:]
y = processed_data[:,0]

# Save processed data
np.savetxt("activity_data.txt", processed_data)

#------------------------------------------------------------------------------------------------------------------
#   End of file
#------------------------------------------------------------------------------------------------------------------

